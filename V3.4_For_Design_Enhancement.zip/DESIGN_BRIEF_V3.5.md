# V3.5 Design Brief: Gemini/Grok-Style Voice UI Enhancement

## Project Context
**App**: PRO + PV Medical Diary - Voice-first medical tracking application  
**Current Version**: V3.4 (working wireframe, minimal voice-first UI)  
**Target Version**: V3.5 (enhanced animations & Gemini/Grok-style polish)

---

## Goal
Transform the current V3.4 voice interface into a **premium, animated experience** rivaling:
- **Google Gemini** (fluid voice interactions, smooth state transitions)
- **Grok by xAI** (playful micro-interactions, engaging feedback)
- **Claude/ChatGPT** (elegant simplicity, thoughtful animations)

---

## Current State (V3.4) - What Works

### ✅ Correct Structure
- App opens on **Voice tab** by default (tab index 1)
- Minimal UI: Live caption card + large mic button + waveform stub
- Bottom navigation: Timeline / Voice / Library / Insights / Profile
- Tone selector in bottom sheet (via "Tune" button)
- Clean separation of concerns (voice-first architecture)

### ✅ Current Components
- `VoiceHubScreen` - Main voice interface
- `_BigMicButton` - 108x108 circular mic button (turns red when listening)
- `_WaveformStub` - Placeholder waveform (static container)
- Live caption card with simulated text updates

---

## Target Enhancements (V3.5)

### 1. **Mic Button Animation** 🔴
**Inspiration**: Gemini's pulsing mic, Grok's playful press feedback

**Requirements**:
- **Idle state**: Subtle breathing/pulse animation (gentle scale 1.0 → 1.05, infinite loop, 2s duration)
- **Active/Listening state**: 
  - More pronounced pulse (scale 1.0 → 1.15, faster 1s duration)
  - Radial ripple effects on tap (2-3 expanding circles)
  - Color transition: Primary blue → Red (with intermediate states)
- **Tap feedback**: Quick scale down (0.95) then bounce back (with overshoot)
- **Long press detection**: Visual feedback when holding (shrinking ring indicator)

**Technical Notes**:
- Use `AnimatedContainer` for smooth color/scale transitions
- Use `AnimationController` with `Tween` for pulse effects
- Consider `Hero` widget for seamless transitions if navigating away

---

### 2. **Waveform Animation** 📊
**Inspiration**: Gemini's real-time waveform, Grok's audio visualization

**Requirements**:
- Replace static `_WaveformStub` with **animated waveform bars**
- **Idle**: 4-6 subtle bars with gentle random height variations (breathing effect)
- **Listening**: Bars react to audio levels (use `FakeWaveform` but enhance it)
- **Bars style**:
  - Rounded tops (pill-shaped)
  - Smooth height transitions (no jumps)
  - Color gradient: Primary → Accent → Primary
  - Responsive to simulated audio input (even if it's fake)

**Technical Notes**:
- Enhance existing `FakeWaveform` widget in `lib/shared/widgets/components.dart`
- Use `CustomPaint` with `CustomPainter` for smooth bars
- Consider using `AnimatedBuilder` with `Listenable` for reactive updates

---

### 3. **Live Caption Animation** 💬
**Inspiration**: ChatGPT's typewriter effect, Claude's smooth text appearance

**Requirements**:
- **Text appearance**: Typewriter effect when new text arrives
- **Text updates**: Smooth fade-out old text, fade-in new text (crossfade)
- **Empty state**: Subtle placeholder animation (three dots pulsing "...")
- **Loading state**: Skeleton shimmer effect while processing

**Technical Notes**:
- Use `AnimatedSwitcher` for text transitions
- Implement typewriter effect with `Timer` and string slicing
- Consider `shimmer` package or custom `ShaderMask` for loading states

---

### 4. **State Transitions** 🎬
**Inspiration**: Gemini's smooth screen transitions, Grok's page transitions

**Requirements**:
- **Ready → Listening**: Smooth expand animation (mic grows, caption area adjusts)
- **Listening → Processing**: Subtle scale-down with opacity change
- **Processing → Ready**: Gentle fade-in with scale-up
- **Bottom sheet (Tone selector)**: Slide up with spring animation (bouncy entrance)
- **Tab switching**: Smooth page transitions (no jarring jumps)

**Technical Notes**:
- Use `Hero` animations for shared elements
- Consider `PageView` with custom `PageTransitionsBuilder`
- Use `Curves` like `Curves.easeOutCubic`, `Curves.elasticOut` for playful feel

---

### 5. **Micro-interactions** ✨
**Inspiration**: Grok's playful details, ChatGPT's thoughtful touches

**Requirements**:
- **Button hover/press**: Scale + shadow elevation change
- **Chip selection (tone)**: Scale + color transition with checkmark animation
- **Toggle switches**: Smooth thumb slide with color gradient
- **Empty states**: Subtle icon animations (gentle bounce)
- **Success feedback**: Confetti/particle effect when event saved (optional, future)

**Technical Notes**:
- Use `InkWell` with `InkResponse` for touch feedback
- Implement custom `AnimatedSwitcher` for state changes
- Consider `flutter_animate` package for advanced animations

---

### 6. **Color & Visual Polish** 🎨
**Inspiration**: Gemini's clean Material 3, Grok's vibrant accents

**Requirements**:
- **Color palette**: Use existing `AppColors` but enhance with:
  - Gradient overlays on mic button
  - Subtle glassmorphism on caption card (backdrop blur)
  - Dark mode support with proper contrast
- **Typography**: Ensure text scales smoothly (already using `TextScaler.linear(0.92)`)
- **Spacing**: Tighten if needed (use `AppTokens` - one step at a time)
- **Shadows**: Subtle elevation shadows (not heavy, modern feel)

**Technical Notes**:
- Review `lib/core/theme/app_theme.dart` for Material 3 compliance
- Use `BackdropFilter` for glassmorphism (test performance)
- Ensure accessibility (WCAG contrast ratios)

---

## Key Files to Modify

### Primary Files (Must Share)
1. **`lib/features/assistant/screens/voice_hub_screen.dart`**
   - Main voice interface
   - Contains `_BigMicButton` and `_WaveformStub`
   - Needs animation enhancements

2. **`lib/shared/widgets/components.dart`**
   - Contains `FakeWaveform` widget (needs enhancement)
   - Contains `MicFab` (may be useful reference)
   - Shared components used across app

3. **`lib/core/theme/app_theme.dart`**
   - Theme configuration
   - Material 3 setup
   - Color definitions

4. **`lib/core/constants/tokens.dart`**
   - Design tokens (spacing, durations)
   - Animation timing constants

5. **`lib/app/app_state.dart`**
   - Global state management
   - Voice tone, hands-free mode
   - May need animation state flags

### Reference Files (Good to Share)
6. **`lib/app/app_shell.dart`** - Navigation structure
7. **`pubspec.yaml`** - Dependencies (may need animation packages)
8. **`DESIGN_TOKENS.md`** - Existing design documentation
9. **`CHANGELOG_V3_4.md`** - Context on what changed in V3.4

---

## Technical Constraints

### ✅ Must Keep
- **No new major dependencies** (unless absolutely necessary)
- **Keep existing architecture** (voice-first, tab structure)
- **Maintain V3.4 navigation** (Voice tab default, Library tab, etc.)
- **Wireframe behavior** (no real STT/LLM yet - just UI)

### ✅ Can Add
- Animation packages if needed: `flutter_animate`, `animations`, `lottie` (for complex animations)
- **Performance**: All animations must be smooth (60fps)
- **Accessibility**: Maintain semantic labels, screen reader support

---

## Design References

### Gemini Voice UI
- Large, centered mic button with pulse
- Real-time waveform visualization
- Smooth state transitions
- Clean, minimal Material 3 design

### Grok Voice UI
- Playful micro-interactions
- Vibrant color accents
- Engaging feedback animations
- Fun, approachable feel

### Claude/ChatGPT Design
- Elegant simplicity
- Thoughtful typography
- Smooth text animations
- Professional polish

---

## Success Criteria

### User Experience
- [ ] Mic button feels responsive and engaging
- [ ] Waveform provides clear visual feedback
- [ ] Caption text appears smoothly
- [ ] State transitions are seamless
- [ ] Overall feel is premium and polished

### Technical
- [ ] All animations run at 60fps
- [ ] No performance degradation
- [ ] Code is maintainable and well-structured
- [ ] Follows Flutter best practices
- [ ] Accessible (screen readers, contrast)

### Visual
- [ ] Matches or exceeds Gemini/Grok quality
- [ ] Consistent with Material 3 guidelines
- [ ] Works in both light and dark mode
- [ ] Responsive to different screen sizes

---

## Next Steps

1. **Review this brief** with design team (Claude/ChatGPT)
2. **Share key files** listed above
3. **Implement animations** one feature at a time (start with mic button)
4. **Test on device** (animations can behave differently in emulator)
5. **Iterate** based on feedback

---

## Prompt for AI Designer (Claude/ChatGPT)

> "You are an expert Flutter UI/UX designer specializing in voice-first interfaces. I need you to enhance the voice interface of a medical diary app (V3.4) to match the quality and animations of Google Gemini, Grok by xAI, and Claude's voice interfaces.
>
> **Current state**: The app has a working wireframe with a minimal voice-first UI. The main screen shows a large mic button, live caption area, and a waveform placeholder. The structure is correct (voice-first architecture) but needs premium animations and polish.
>
> **Your task**: Enhance the animations, micro-interactions, and visual design to create a premium, engaging experience. Focus on:
> 1. Animated mic button (pulse, ripples, smooth color transitions)
> 2. Animated waveform bars (reactive to audio levels)
> 3. Smooth caption text animations (typewriter, crossfade)
> 4. Seamless state transitions
> 5. Playful micro-interactions
> 6. Material 3 polish
>
> **Constraints**: 
> - Keep existing architecture (voice-first, tab structure)
> - No real audio processing yet (use simulated/fake data)
> - Maintain performance (60fps)
> - Follow Flutter best practices
> - Use existing design tokens where possible
>
> **Files provided**: [List the key files you're sharing]
>
> Please review the code, understand the structure, and provide enhanced implementations with smooth, engaging animations. Include comments explaining animation choices and performance considerations."

---

**Version**: 1.0  
**Date**: 2025-01-09  
**Author**: V3.4 → V3.5 Enhancement Brief

