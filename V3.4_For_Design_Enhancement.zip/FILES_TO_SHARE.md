# Files to Share with AI Designer (Claude/ChatGPT)

## Essential Files (Must Share)

### 1. Voice Interface Core
- `lib/features/assistant/screens/voice_hub_screen.dart` ⭐ **PRIMARY**
  - Main voice screen with mic button and caption
  - Contains `_BigMicButton` and `_WaveformStub` widgets
  - This is the main file to enhance

### 2. Shared Components
- `lib/shared/widgets/components.dart` ⭐ **PRIMARY**
  - Contains `FakeWaveform` widget (needs animation enhancement)
  - Contains `MicFab` widget (reference for mic button styles)
  - Shared UI components

### 3. Theme & Design System
- `lib/core/theme/app_theme.dart`
  - Material 3 theme configuration
  - Light/dark theme setup
  - Color scheme definitions

- `lib/core/constants/tokens.dart`
  - Design tokens (spacing, durations, sizes)
  - Animation timing constants
  - Color palette (`AppColors`)

### 4. State Management
- `lib/app/app_state.dart`
  - Global app state (voice tone, hands-free mode)
  - May need animation state flags

### 5. Configuration
- `pubspec.yaml`
  - Project dependencies
  - May need to add animation packages

---

## Context Files (Highly Recommended)

### 6. Architecture Overview
- `lib/app/app_shell.dart`
  - Navigation structure
  - Tab configuration
  - Overall app layout

### 7. Documentation
- `DESIGN_TOKENS.md`
  - Existing design system documentation
- `CHANGELOG_V3_4.md`
  - What changed in V3.4
  - Context on voice-first architecture
- `DESIGN_BRIEF_V3.5.md` ⭐ **SHARE THIS**
  - Complete design brief with requirements
  - Technical specifications
  - Design references

### 8. Project Structure
- `lib/main.dart`
  - App entry point
  - Basic setup

---

## Optional Reference Files

### 9. Other Screens (For Context)
- `lib/features/library/screens/library_screen.dart`
  - Shows how other screens are structured
- `lib/features/home/screens/home_screen.dart`
  - Timeline screen (for understanding navigation)

---

## Files to EXCLUDE (Don't Share)

### Build Artifacts
- `build/` folder (entire directory)
- `android/app/build/` folder
- `android/.gradle/` folder
- `.dart_tool/` folder
- `*.iml` files (IntelliJ project files)

### Generated Files
- `pubspec.lock` (can regenerate)
- `android/local.properties` (machine-specific)
- `flutter_log.txt` (temporary log)

### Backup Files
- Any `*.bak` folders
- `ChatGPT Files/` folder (old zips)

---

## Recommended Sharing Method

### Option 1: Selective File Share
Share only the essential files listed above (1-5) plus the design brief.

### Option 2: Clean Zip Archive
Create a zip with:
```
beforedoctor4/
├── lib/
│   ├── app/
│   │   ├── app_shell.dart
│   │   └── app_state.dart
│   ├── core/
│   │   ├── constants/tokens.dart
│   │   └── theme/app_theme.dart
│   ├── features/
│   │   └── assistant/screens/voice_hub_screen.dart
│   ├── shared/widgets/components.dart
│   └── main.dart
├── pubspec.yaml
├── DESIGN_BRIEF_V3.5.md
├── DESIGN_TOKENS.md
├── CHANGELOG_V3_4.md
└── README.md
```

### Option 3: GitHub Gist
Create a Gist with the key files for easy sharing.

---

## Instructions for AI Designer

When sharing files, include this message:

> "I'm working on a Flutter voice-first medical diary app. The current V3.4 version has the correct structure but needs premium animations and polish to match Gemini/Grok voice interfaces.
>
> **Please review these files and the DESIGN_BRIEF_V3.5.md document for full requirements.**
>
> **Focus Areas:**
> 1. Enhance `voice_hub_screen.dart` with smooth mic button animations
> 2. Improve `FakeWaveform` in `components.dart` with animated bars
> 3. Add smooth caption text animations
> 4. Implement seamless state transitions
> 5. Polish micro-interactions throughout
>
> **Constraints:**
> - Keep existing architecture (no structural changes)
> - Use simulated data (no real audio yet)
> - Maintain 60fps performance
> - Follow Flutter best practices
>
> Please provide enhanced code with detailed comments explaining animation choices."

---

**Last Updated**: 2025-01-09

