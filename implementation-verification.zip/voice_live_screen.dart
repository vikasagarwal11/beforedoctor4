// lib/features/voice/screens/voice_live_screen.dart
//
// Gemini-Live style screen wired to VoiceSessionController.
//
// This is a DROP-IN screen. You must provide:
// - gatewayUrl (wss://...)
// - firebaseIdToken (from your auth layer; do NOT hardcode in production)
// - a sessionConfig map (system instruction, schema, etc.)
// - choose MockGatewayClient during UI testing, GatewayClient for real gateway

import 'package:flutter/material.dart';

import '../../../data/models/adverse_event_report.dart';
import '../../../services/audio/audio_engine_service.dart';
import '../../../services/audio/native_audio_engine.dart';
import '../../../services/gateway/gateway_client.dart';
import '../../../services/gateway/mock_gateway_client.dart';
import '../voice_session_controller.dart';

class VoiceLiveScreen extends StatefulWidget {
  final Uri gatewayUrl;
  final String firebaseIdToken;
  final Map<String, dynamic> sessionConfig;

  /// Set true to run without backend (UI test).
  final bool useMockGateway;

  const VoiceLiveScreen({
    super.key,
    required this.gatewayUrl,
    required this.firebaseIdToken,
    required this.sessionConfig,
    this.useMockGateway = true,
  });

  @override
  State<VoiceLiveScreen> createState() => _VoiceLiveScreenState();
}

class _VoiceLiveScreenState extends State<VoiceLiveScreen> with SingleTickerProviderStateMixin {
  late final VoiceSessionController _controller;
  late final AnimationController _aura;

  bool _detailsOpen = false;

  @override
  void initState() {
    super.initState();

    _aura = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);

    final IGatewayClient gateway = widget.useMockGateway ? MockGatewayClient() : GatewayClient();
    final IAudioEngine audio = widget.useMockGateway ? NoOpAudioEngine() : NativeAudioEngine();

    _controller = VoiceSessionController(gateway: gateway, audio: audio);

    // Auto-start
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _controller.start(
        gatewayUrl: widget.gatewayUrl,
        firebaseIdToken: widget.firebaseIdToken,
        sessionConfig: widget.sessionConfig,
      );
    });
  }

  @override
  void dispose() {
    _aura.dispose();
    _controller.dispose();
    super.dispose();
  }

  Color _auraColor() {
    if (_controller.uiState == VoiceUiState.emergency) return Colors.redAccent;
    return Colors.blueAccent;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_aura, _controller]),
      builder: (context, _) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            children: [
              _buildAura(),
              SafeArea(
                child: Column(
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 14),
                    Expanded(child: _buildTranscriptArea()),
                    _buildDock(),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAura() {
    final base = _auraColor();
    final intensity = 0.25 + (_aura.value * 0.35);

    return Positioned(
      bottom: -120,
      left: -80,
      right: -80,
      child: Container(
        height: 520,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              base.withOpacity(intensity),
              base.withOpacity(0.08),
              Colors.transparent,
            ],
            stops: const [0.0, 0.45, 1.0],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final label = switch (_controller.uiState) {
      VoiceUiState.ready => 'Ready',
      VoiceUiState.connecting => 'Connecting…',
      VoiceUiState.listening => 'Listening',
      VoiceUiState.speaking => 'Speaking',
      VoiceUiState.processing => 'Processing…',
      VoiceUiState.emergency => 'Urgent',
      VoiceUiState.stopped => 'Stopped',
      VoiceUiState.error => 'Error',
    };

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Center(
              child: Text(
                label,
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          IconButton(
            onPressed: () => _toggleDetails(context),
            icon: const Icon(Icons.tune, color: Colors.white),
            tooltip: 'Details',
          ),
        ],
      ),
    );
  }

  Widget _buildTranscriptArea() {
    final partial = _controller.transcriptPartial.trim();
    final finalText = _controller.transcriptFinal.trim();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_controller.uiState == VoiceUiState.emergency && (_controller.emergencyBanner?.isNotEmpty ?? false))
            _EmergencyBanner(text: _controller.emergencyBanner!, onDismiss: _controller.clearEmergency),

          const SizedBox(height: 10),

          if (finalText.isNotEmpty)
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  finalText,
                  style: const TextStyle(color: Colors.white70, fontSize: 16, height: 1.35),
                ),
              ),
            )
          else
            const Spacer(),

          if (partial.isNotEmpty)
            _Bubble(text: partial, alignRight: false),

          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _buildDock() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 26, left: 14, right: 14, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _DockButton(
            icon: Icons.description_outlined,
            onPressed: () => _toggleDetails(context),
          ),
          _DockButton(
            icon: Icons.mic,
            onPressed: () {
              // In V1 we auto-start capture. You can add pause/resume here.
            },
          ),
          _DockButton(
            icon: Icons.stop_circle_outlined,
            wide: true,
            color: Colors.redAccent,
            onPressed: () async {
              await _controller.stop();
              if (mounted) Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  Future<void> _toggleDetails(BuildContext context) async {
    if (_detailsOpen) return;
    _detailsOpen = true;

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0B0B0B),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _DetailsSheet(controller: _controller),
    );

    _detailsOpen = false;
  }
}

class _DockButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  final bool wide;
  final Color color;

  const _DockButton({
    required this.icon,
    this.onPressed,
    this.wide = false,
    this.color = const Color(0xFF333639),
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: wide ? 92 : 66,
      height: 52,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
          padding: EdgeInsets.zero,
        ),
        onPressed: onPressed,
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final String text;
  final bool alignRight;

  const _Bubble({required this.text, required this.alignRight});

  @override
  Widget build(BuildContext context) {
    final bg = const Color(0xFF202124);
    return Align(
      alignment: alignRight ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 520),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.35)),
      ),
    );
  }
}

class _EmergencyBanner extends StatelessWidget {
  final String text;
  final VoidCallback onDismiss;

  const _EmergencyBanner({required this.text, required this.onDismiss});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.redAccent.withOpacity(0.18),
        border: Border.all(color: Colors.redAccent.withOpacity(0.55)),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.25))),
          IconButton(
            onPressed: onDismiss,
            icon: const Icon(Icons.close, color: Colors.white70),
          ),
        ],
      ),
    );
  }
}

class _DetailsSheet extends StatelessWidget {
  final VoiceSessionController controller;

  const _DetailsSheet({required this.controller});

  @override
  Widget build(BuildContext context) {
    final report = controller.draft;
    final c = report.criteria;

    return Padding(
      padding: EdgeInsets.only(
        left: 18,
        right: 18,
        top: 18,
        bottom: 18 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Report Details', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 14),
            _CriteriaRow(label: 'Identifiable Patient', ok: c.hasIdentifiablePatient),
            _CriteriaRow(label: 'Identifiable Reporter', ok: c.hasIdentifiableReporter),
            _CriteriaRow(label: 'Suspect Product', ok: c.hasSuspectProduct),
            _CriteriaRow(label: 'Adverse Event', ok: c.hasAdverseEvent),
            const SizedBox(height: 14),
            _KeyValue(label: 'Product', value: _val(report.productDetails['product_name'] ?? report.productDetails['name'])),
            _KeyValue(label: 'Symptoms', value: _symptoms(report.eventDetails['symptoms'])),
            const SizedBox(height: 12),
            const Text('Narrative Preview', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF141414),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                report.narrative.isEmpty ? '—' : report.narrative,
                style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.35),
              ),
            ),
            const SizedBox(height: 16),
            _KeyValue(label: 'Draft Valid', value: report.criteria.isValid ? 'Yes' : 'No'),
            const SizedBox(height: 6),
            Text(
              'Before submission, add a final attestation step (name + timestamp).',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }

  static String _val(dynamic v) => (v == null) ? '—' : v.toString().trim().isEmpty ? '—' : v.toString();

  static String _symptoms(dynamic v) {
    if (v is List) {
      if (v.isEmpty) return '—';
      return v.map((e) => e.toString()).join(', ');
    }
    return _val(v);
  }
}

class _CriteriaRow extends StatelessWidget {
  final String label;
  final bool ok;

  const _CriteriaRow({required this.label, required this.ok});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle : Icons.circle_outlined, color: ok ? Colors.lightBlueAccent : Colors.white24),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 14))),
        ],
      ),
    );
  }
}

class _KeyValue extends StatelessWidget {
  final String label;
  final String value;

  const _KeyValue({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 86,
            child: Text(label, style: const TextStyle(color: Colors.white54, fontSize: 13)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.white70, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}
