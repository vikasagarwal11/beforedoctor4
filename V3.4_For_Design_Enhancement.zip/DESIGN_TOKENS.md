Design Tokens (Wireframe)

This project uses a small token layer to keep UI consistent.

- lib/src/app/tokens.dart
  - AppTokens: spacing, radii, elevations
  - AppColors: core palette (light/dark friendly)

Production recommendation
- Promote tokens into a formal system:
  - color roles: primary/secondary/tertiary, surface roles, outline roles
  - semantic statuses: success/warn/danger/info
  - typography scale: title/body/label with platform-specific adjustments
- Mirror tokens in Figma variables to keep design/dev in sync.
