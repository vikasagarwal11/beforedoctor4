#!/bin/bash
echo "Starting BeforeDoctor Gateway Server..."
echo ""
node server.js

