# Cursor application prompt – V3.4.1 Voice polish

Use this prompt in Cursor AFTER unzipping V3.4.1 into your working Flutter repo.

## Prompt
You are updating my Flutter project to V3.4.1 (voice UI polish). Apply changes exactly from the provided zip.

Requirements:
1) Replace the Voice screen implementation with the new modular version:
   - `lib/features/voice/screens/voice_screen.dart`
   - `lib/features/voice/widgets/*`
2) Update navigation so the Voice tab uses `VoiceScreen`:
   - `lib/app/app_shell.dart` should import `VoiceScreen` and use it for the Voice page.
3) Keep all existing non-voice modules unchanged.
4) Do not introduce new business logic, network calls, or packages.
5) Ensure `flutter pub get` and `flutter run` succeed.

After applying, run:
- `flutter pub get`
- `flutter analyze` (fix any warnings only if they are real errors)
- `flutter run`

Do NOT redesign the voice screen beyond what the code provides.
