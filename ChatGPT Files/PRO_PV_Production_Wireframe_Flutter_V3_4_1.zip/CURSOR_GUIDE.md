You are working inside a production-style Flutter UI wireframe project.
Goal: make precise, minimal, compiling changes. Do NOT redesign screens.

Non-negotiables
- Keep the existing navigation structure and screen list.
- Do not add new packages/dependencies unless explicitly requested.
- Do not change app purpose, naming, or user flows.
- Maintain current folder structure under lib/src (app, data, models, ui).
- All changes must compile with `flutter analyze` and run with `flutter run`.

Default behavior
- Prefer editing tokens and shared components over editing many screens.
- Use AppTokens/AppColors for spacing and colors. Do not hardcode random values.
- When adjusting density/spacing, change 1 token step at a time:
  xs -> sm -> md -> lg -> xl
- When adjusting typography, prefer global text scaling (AppState.textScale) or Theme text styles.
- Keep interactive behavior as UI-only; do not implement business logic, APIs, auth, or databases.

Allowed changes (safe)
- Tighten spacing by updating AppTokens or converting padding from lg to md in key components.
- Reduce font sizes by adjusting AppState default textScale (e.g., 1.0 -> 0.92) OR Theme text styles.
- Improve card layout consistency using shared widgets (SectionHeader, StatusChip, etc.).
- Add missing empty/loading/error states using existing `states.dart` components.
- Minor UI polish: alignment, overflow handling, consistent icon sizes.

Forbidden changes (must not do)
- Do not introduce state management libraries (Provider/Riverpod/Bloc/etc.).
- Do not replace FakeWaveform with real audio packages unless explicitly requested.
- Do not restructure screens into a different UX paradigm (no new tabs, no new drawer, no new IA).
- Do not rename files/classes broadly or move files across folders.
- Do not remove any existing screen.

How to work (process)
1) Identify exact files to change and explain why (brief).
2) Make the smallest edit that accomplishes the request.
3) Ensure imports remain correct and there are no unused imports.
4) Confirm no new warnings are introduced.

When asked to “make it denser”
- First: make Compact density default in AppShell OR reduce AppTokens card padding by one step.
- Second: reduce vertical gaps between cards by one token step.
- Third: only if needed, reduce ListTile vertical density (not all fonts).

When asked to “reduce fonts”
- First: change AppState default `textScale` (e.g., 1.0 -> 0.92).
- Second: reduce headline/title styles slightly in theme (not body text first).

Output requirements
- Provide exact file paths changed.
- Provide the exact code diff or full file content only when asked.
- Do not propose large rewrites.
