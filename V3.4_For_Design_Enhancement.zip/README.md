PRO + PV Production Wireframe (Flutter) — V2 (Design-system + States)

What this is
- Standalone, production-style UI wireframe for an Episode-based, voice-first PRO + PV app.
- Includes a lightweight design system layer, component gallery, and common production UI states:
  - offline banner / queued states
  - empty states
  - error + retry state
  - skeleton loaders (visual only)

Important
- No business logic, no backend, no real audio capture.
- Voice waveform/transcript remain simulated.

New in V2
- Global UI toggles (Privacy screen):
  - Simulate offline
  - Compact density
  - Text scale slider
- Component gallery (Profile → Design system → Component gallery)
- Offline banner appears on key screens
- DESIGN_TOKENS.md added

Run it
flutter pub get
flutter run

Cursor workflow
- Open the folder in Cursor.
- Ask Cursor to tweak spacing, typography, colors, and component styles.
- Because this is a compiling project with a component gallery, Cursor changes are easier to verify and less likely to break UX consistency.

Next (production upgrades, not included)
- Real mic capture (record/flutter_sound), VAD, streaming ASR (on-device + cloud)
- Encrypted local store, sync engine, audit logs
- PV case workflows, follow-up, and regulator submission packaging
