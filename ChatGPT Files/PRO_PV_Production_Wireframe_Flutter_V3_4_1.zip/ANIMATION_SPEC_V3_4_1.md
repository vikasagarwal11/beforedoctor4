# V3.4.1 Animation Spec – Voice Surface (Mic + Waveform)

This spec describes the exact intended motion for the voice-first screen so implementation stays consistent across developers/tools.

## 1) Mic button (primary)

### Layout
- Button diameter: **112dp**
- Pulse ring diameter (rest): **132dp**
- Icon size: **44dp**
- Centered vertically below caption card; spacing ~24dp.

### States
**Idle**
- Solid fill: `colorScheme.primary`
- No ring
- Shadow: blur 24dp, y-offset 12dp, opacity ~0.18

**Listening**
- Fill: **Red** (wireframe; later map to state color system)
- Icon changes to **stop** icon
- **Pulse ring**: visible; expands outward continuously

**Thinking** (placeholder in code; enable later)
- Fill: `colorScheme.secondary`
- Ring optional: faint slow pulse
- Add subtle spinner halo (future)

**Speaking** (future)
- Fill remains primary/secondary depending on tone
- Glow ripple synced to TTS amplitude (future)

### Interactions
**Press**
- Scale up from **1.00 → 1.06**
- Duration: **120ms**
- Curve: easeOut
- Release returns to 1.0 with same duration.

**Pulse ring (Listening)**
- Repeating controller duration: **1200ms**
- Ring scale: **1.00 → 1.65**
- Opacity: **0.28 → 0.12** (fade out as it expands)
- Border width: **10dp**
- Curve: linear (more “metronomic” like voice UI)

## 2) Waveform (wireframe “alive” placeholder)

### Container
- Height: **64dp**
- Border radius: **18dp**
- Background: `colorScheme.surface` at ~0.6 opacity
- Border: `outlineVariant` at ~0.45 opacity

### Bars
- Count: **12**
- Shape: pill (radius 999)
- Spacing: 2dp horizontal padding per bar
- Color:
  - idle: primary @ 0.60–0.70
  - listening: primary @ 0.75
  - thinking: primary @ 0.55 (slightly muted)

### Motion
- Animation controller: **900ms** repeating
- Each bar heightFactor uses a sine:
  - Idle: base 0.18, wobble 0.35
  - Listening: base 0.55, wobble 0.35 (taller, more energetic)
  - Thinking: base 0.28, wobble 0.18 (slower/more restrained)

> This is intentionally “fake but believable” until real audio metering is added.

## 3) Captions transitions (“live caption”)

### Transition
- Use AnimatedSwitcher per caption change.
- Duration: **220ms**
- In: fade 0→1 + slide Y **6% down → 0**
- Out: reverse fade/slide
- Curves:
  - in: easeOutCubic
  - out: easeInCubic

### Typography
- Caption text: `headlineSmall`, height 1.15
- Label: `titleSmall` using `onSurfaceVariant`

## 4) Presence header
- Left breathing dot:
  - outer circle: size 18→24 oscillation
  - cycle: **1600ms** repeat reverse
  - inner dot fixed 6dp
- Status text: `titleMedium`
- Tone button: outlined with tune icon

## Success criteria (visual)
- Screen feels “alive” even when idle
- Listening state is obvious without reading
- Motion is subtle (no jank) and stays at 60fps
