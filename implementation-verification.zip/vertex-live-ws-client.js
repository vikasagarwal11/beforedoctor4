// Vertex AI Live WebSocket Client
// Production-grade: True bidirectional WebSocket connection to Vertex Live API
// Replaces the placeholder chat-based implementation

import WebSocket from 'ws';
import { GoogleAuth } from 'google-auth-library';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { config } from './config.js';
import { logger } from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Vertex Live WebSocket Session Manager
 * Implements the true bidirectional WebSocket connection to Vertex AI Live API
 */
export class VertexLiveWSSession {
  constructor(sessionConfig) {
    this.sessionConfig = sessionConfig;
    this.ws = null;
    this.auth = null;
    this.accessToken = null;
    this.isConnected = false;
    this.isSetup = false;
    this.eventHandlers = {
      transcript: [],
      audio: [],
      bargeIn: [],
      draftUpdate: [],
      narrativeUpdate: [],
      error: [],
    };
  }

  /**
   * Initialize authentication
   * Uses Application Default Credentials (ADC) for OAuth2 bearer tokens
   */
  async initialize() {
    try {
      let authMethod = 'application_default_credentials';
      let credentials = null;

      // Production: Use Application Default Credentials (ADC)
      if (process.env.NODE_ENV === 'production' || !config.firebase.serviceAccountPath) {
        logger.info('vertex.initializing', {
          method: 'application_default_credentials',
          project: config.vertexAI.projectId,
          location: config.vertexAI.location,
        });
      } else {
        // Development: Use service account file if provided
        try {
          const serviceAccountPath = config.firebase.serviceAccountPath.startsWith('./')
            ? join(__dirname, config.firebase.serviceAccountPath.replace('./', ''))
            : config.firebase.serviceAccountPath;
          
          const serviceAccountJson = readFileSync(serviceAccountPath, 'utf8');
          credentials = JSON.parse(serviceAccountJson);
          authMethod = 'service_account_file';
          
          logger.info('vertex.initializing', {
            method: 'service_account_file',
            service_account: credentials.client_email,
            project: config.vertexAI.projectId,
            location: config.vertexAI.location,
          });
        } catch (e) {
          logger.warn('vertex.service_account_file_failed', {
            error: e.message,
            fallback: 'application_default_credentials',
          });
        }
      }

      // Initialize Google Auth for OAuth2 token
      this.auth = new GoogleAuth({
        scopes: ['https://www.googleapis.com/auth/cloud-platform'],
        ...(credentials && { credentials }),
      });

      // Get access token
      const client = await this.auth.getClient();
      const tokenResponse = await client.getAccessToken();
      this.accessToken = tokenResponse.token;

      if (!this.accessToken) {
        throw new Error('Failed to obtain OAuth2 access token');
      }

      logger.info('vertex.authenticated', {
        auth_method: authMethod,
        project_id: config.vertexAI.projectId,
      });

    } catch (error) {
      logger.error('vertex.initialization_failed', {
        error_code: error.code,
        error_message: error.message,
        project: config.vertexAI.projectId,
      });
      throw error;
    }
  }

  /**
   * Start Vertex Live WebSocket session
   * Connects to Vertex Live API and sends setup message
   */
  async startSession() {
    try {
      if (!this.accessToken) {
        throw new Error('Not initialized - call initialize() first');
      }

      // Build WebSocket URL
      const location = config.vertexAI.location;
      const wsUrl = `wss://${location}-aiplatform.googleapis.com/ws/google.cloud.aiplatform.v1.LlmBidiService/BidiGenerateContent`;

      logger.info('vertex.connecting', {
        url: wsUrl.replace(this.accessToken, '[REDACTED]'),
        location: location,
      });

      // Connect to Vertex Live WebSocket
      this.ws = new WebSocket(wsUrl, {
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      // Handle connection open
      this.ws.on('open', () => {
        logger.info('vertex.websocket_connected', {});
        this.isConnected = true;
        this._sendSetupMessage();
      });

      // Handle incoming messages
      this.ws.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString());
          this._handleVertexMessage(message);
        } catch (error) {
          logger.error('vertex.message_parse_failed', {
            error_message: error.message,
          });
          this.emit('error', error);
        }
      });

      // Handle connection close
      this.ws.on('close', (code, reason) => {
        logger.info('vertex.websocket_closed', {
          code: code,
          reason: reason?.toString(),
        });
        this.isConnected = false;
        this.isSetup = false;
      });

      // Handle errors
      this.ws.on('error', (error) => {
        logger.error('vertex.websocket_error', {
          error_code: error.code,
          error_message: error.message,
        });
        this.isConnected = false;
        this.emit('error', error);
      });

      // Wait for connection to be established
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('WebSocket connection timeout'));
        }, 10000);

        this.ws.once('open', () => {
          clearTimeout(timeout);
          resolve();
        });

        this.ws.once('error', (error) => {
          clearTimeout(timeout);
          reject(error);
        });
      });

      // Wait for setup to complete
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Setup message timeout'));
        }, 5000);

        const checkSetup = setInterval(() => {
          if (this.isSetup) {
            clearTimeout(timeout);
            clearInterval(checkSetup);
            resolve();
          }
        }, 100);

        this.ws.once('error', (error) => {
          clearTimeout(timeout);
          clearInterval(checkSetup);
          reject(error);
        });
      });

      logger.info('vertex.session_started', {
        has_system_instruction: !!this.sessionConfig.system_instruction,
      });

    } catch (error) {
      logger.error('vertex.session_start_failed', {
        error_code: error.code,
        error_message: error.message,
      });
      throw error;
    }
  }

  /**
   * Send setup message (first message after connection)
   * This defines the "Brain" of the agent
   */
  _sendSetupMessage() {
    try {
      const systemInstruction = this.sessionConfig.system_instruction?.text || 
        'You are a professional PV (Pharmacovigilance) Intake Specialist for adverse event reporting. ' +
        'You are empathetic, thorough, and professional. ' +
        'Ask follow-up questions until you have all 4 minimum criteria: ' +
        '1) identifiable patient (age OR gender OR initials), ' +
        '2) identifiable reporter (role OR contact OR authenticated user), ' +
        '3) suspect product (name), ' +
        '4) adverse event (symptom(s) or narrative). ' +
        'Use the update_ae_draft tool to update the adverse event report as you gather information.';

      const setupMessage = {
        setup: {
          model: `projects/${config.vertexAI.projectId}/locations/${config.vertexAI.location}/publishers/google/models/gemini-2.5-flash-native-audio`,
          generation_config: {
            response_modalities: ['AUDIO'],
            speech_config: {
              voice_config: {
                prebuilt_voice_config: {
                  voice_name: 'Puck', // Professional, empathetic voice
                },
              },
            },
            temperature: 0.7,
            top_p: 0.95,
            top_k: 40,
          },
          system_instruction: {
            parts: [
              {
                text: systemInstruction,
              },
            ],
          },
          tools: [
            {
              function_declarations: [
                {
                  name: 'update_ae_draft',
                  description: 'Update the adverse event report draft with extracted information',
                  parameters: {
                    type: 'OBJECT',
                    properties: {
                      patient_info: {
                        type: 'OBJECT',
                        properties: {
                          initials: { type: 'STRING' },
                          age: { type: 'INTEGER' },
                          gender: { type: 'STRING' },
                        },
                      },
                      product_details: {
                        type: 'OBJECT',
                        properties: {
                          product_name: { type: 'STRING' },
                          dosage_strength: { type: 'STRING' },
                          frequency: { type: 'STRING' },
                          indication: { type: 'STRING' },
                          lot_number: { type: 'STRING' },
                        },
                      },
                      event_details: {
                        type: 'OBJECT',
                        properties: {
                          symptoms: {
                            type: 'ARRAY',
                            items: { type: 'STRING' },
                          },
                          onset_date: { type: 'STRING' },
                          duration: { type: 'STRING' },
                          outcome: { type: 'STRING' },
                          narrative: { type: 'STRING' },
                        },
                      },
                      seriousness: { type: 'STRING' },
                    },
                  },
                },
                {
                  name: 'update_narrative',
                  description: 'Update the narrative summary of the adverse event',
                  parameters: {
                    type: 'OBJECT',
                    properties: {
                      narrative: { type: 'STRING' },
                    },
                  },
                },
              ],
            },
          ],
        },
      };

      this.ws.send(JSON.stringify(setupMessage));
      logger.info('vertex.setup_sent', {
        model: setupMessage.setup.model,
        has_tools: setupMessage.setup.tools.length > 0,
      });

    } catch (error) {
      logger.error('vertex.setup_send_failed', {
        error_message: error.message,
      });
      this.emit('error', error);
    }
  }

  /**
   * Handle messages from Vertex Live API
   */
  _handleVertexMessage(message) {
    try {
      // Handle setup response
      if (message.setupComplete) {
        logger.info('vertex.setup_complete', {});
        this.isSetup = true;
        return;
      }

      // Handle server content (model responses)
      if (message.serverContent) {
        // Check for interruption (barge-in)
        if (message.serverContent.interrupted === true) {
          logger.vertexAI('barge_in_detected', {});
          this.emit('bargeIn');
        }

        // Handle model turn (audio + text output)
        if (message.serverContent.modelTurn) {
          const parts = message.serverContent.modelTurn.parts || [];

          for (const part of parts) {
            // Handle audio output (24kHz PCM)
            if (part.inlineData && part.inlineData.mimeType?.includes('audio')) {
              const audioData = Buffer.from(part.inlineData.data, 'base64');
              logger.vertexAI('audio_received', {
                has_audio: true,
                audio_size_bytes: audioData.length,
              });
              this.emit('audio', audioData);
            }

            // Handle text (transcript)
            if (part.text) {
              const isPartial = !message.serverContent.modelTurn.complete;
              logger.vertexAI('transcript_received', {
                has_transcript: true,
                is_partial: isPartial,
              });
              this.emit('transcript', {
                text: part.text,
                isPartial: isPartial,
              });
            }

            // Handle function calls (tool calls for draft updates)
            if (part.functionCall) {
              logger.vertexAI('function_call_received', {
                function_name: part.functionCall.name,
              });

              if (part.functionCall.name === 'update_ae_draft') {
                const args = part.functionCall.args || {};
                this.emit('draftUpdate', args);
              }

              if (part.functionCall.name === 'update_narrative') {
                const args = part.functionCall.args || {};
                if (args.narrative) {
                  this.emit('narrativeUpdate', { text: args.narrative });
                }
              }
            }
          }
        }
      }

      // Handle errors
      if (message.error) {
        logger.error('vertex.api_error', {
          error_code: message.error.code,
          error_message: message.error.message,
        });
        this.emit('error', new Error(message.error.message));
      }

    } catch (error) {
      logger.error('vertex.message_handle_failed', {
        error_message: error.message,
      });
      this.emit('error', error);
    }
  }

  /**
   * Send audio chunk to Vertex Live API
   * @param {Buffer} pcm16k - PCM audio bytes (16kHz, s16le, mono)
   */
  async sendAudio(pcm16k) {
    if (!this.ws || !this.isConnected || !this.isSetup) {
      throw new Error('Session not ready - WebSocket not connected or setup not complete');
    }

    try {
      // Convert PCM to base64
      const audioBase64 = pcm16k.toString('base64');

      // Log audio chunk sent (no audio content)
      logger.vertexAI('audio_chunk_sent', {
        chunk_size_bytes: pcm16k.length,
        has_audio: true,
      });

      // Send audio input message
      const inputMessage = {
        input: {
          audio: {
            data: audioBase64,
            mimeType: 'audio/pcm;rate=16000',
          },
        },
      };

      this.ws.send(JSON.stringify(inputMessage));

    } catch (error) {
      logger.error('vertex.audio_send_failed', {
        error_code: error.code,
        error_message: error.message,
      });
      this.emit('error', error);
    }
  }

  /**
   * Event emitter pattern
   */
  on(event, handler) {
    if (this.eventHandlers[event]) {
      this.eventHandlers[event].push(handler);
    }
  }

  off(event, handler) {
    if (this.eventHandlers[event]) {
      this.eventHandlers[event] = this.eventHandlers[event].filter(h => h !== handler);
    }
  }

  emit(event, data) {
    if (this.eventHandlers[event]) {
      this.eventHandlers[event].forEach(handler => {
        try {
          handler(data);
        } catch (error) {
          logger.error(`vertex.event_handler_error`, {
            event: event,
            error_message: error.message,
          });
        }
      });
    }
  }

  /**
   * Close session
   */
  async close() {
    try {
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.isConnected = false;
      this.isSetup = false;
      logger.info('vertex.session_closed', {});
    } catch (error) {
      logger.error('vertex.session_close_failed', {
        error_code: error.code,
        error_message: error.message,
      });
    }
  }
}

export default VertexLiveWSSession;

