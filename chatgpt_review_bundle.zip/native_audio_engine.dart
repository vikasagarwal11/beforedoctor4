// lib/services/audio/native_audio_engine.dart
//
// Native audio engine using:
// - mic_stream: capture raw PCM at 16kHz mono
// - flutter_pcm_sound: play raw PCM at 24kHz mono
//
// IMPORTANT:
// - Validate device permissions before start() (microphone).
// - Some Android devices may not provide true 16kHz; if so, you must resample.
//   (This implementation assumes mic_stream honors the requested sampleRate.)

import 'dart:async';
import 'dart:typed_data';

import 'package:mic_stream/mic_stream.dart';
import 'package:flutter_pcm_sound/flutter_pcm_sound.dart';

import 'audio_engine_service.dart';

class NativeAudioEngine implements IAudioEngine {
  @override
  final IAudioCapture capture = _NativeCapture();

  @override
  final IAudioPlayback playback = _NativePlayback();

  @override
  Future<void> dispose() async {
    await capture.stop();
    await playback.dispose();
  }
}

class _NativeCapture implements IAudioCapture {
  bool _isCapturing = false;
  StreamSubscription<List<int>>? _sub;

  @override
  bool get isCapturing => _isCapturing;

  @override
  Future<void> start({required void Function(Uint8List pcm16k) onPcm16k}) async {
    if (_isCapturing) return;
    _isCapturing = true;

    final stream = await MicStream.microphone(
      audioSource: AudioSource.DEFAULT,
      sampleRate: 16000,
      channelConfig: ChannelConfig.CHANNEL_IN_MONO,
      audioFormat: AudioFormat.ENCODING_PCM_16BIT,
    );

    _sub = stream?.listen((samples) {
      if (!_isCapturing) return;
      onPcm16k(Uint8List.fromList(samples));
    });
  }

  @override
  Future<void> stop() async {
    _isCapturing = false;
    await _sub?.cancel();
    _sub = null;
  }
}

class _NativePlayback implements IAudioPlayback {
  bool _prepared = false;

  @override
  bool get isPlaying => _prepared;

  @override
  Future<void> prepare() async {
    if (_prepared) return;
    await FlutterPcmSound.setup(sampleRate: 24000, channelCount: 1);
    await FlutterPcmSound.play();
    _prepared = true;
  }

  @override
  Future<void> feed(Uint8List pcm24k) async {
    if (!_prepared) {
      await prepare();
    }
    await FlutterPcmSound.feed(PcmArrayInt16(bytes: pcm24k));
  }

  @override
  Future<void> stopNow() async {
    // Critical for barge-in: this flushes internal buffers.
    await FlutterPcmSound.stop();
    _prepared = false;
    await prepare();
  }

  @override
  Future<void> dispose() async {
    await FlutterPcmSound.stop();
    _prepared = false;
  }
}

