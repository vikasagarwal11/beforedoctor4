// lib/features/voice/voice_session_controller.dart
//
// Controller for the Voice Live experience.
// Responsibilities:
// - session state machine
// - receiving gateway events (ordered by seq)
// - applying incremental report patches
// - transcript + narrative preview
// - barge-in (audioStop) => flush playback immediately
// - emergency escalation => UI state + banner

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../../data/models/adverse_event_report.dart';
import '../../services/audio/audio_engine_service.dart';
import '../../services/gateway/gateway_client.dart';
import '../../services/gateway/gateway_protocol.dart';

enum VoiceUiState { ready, connecting, listening, speaking, processing, emergency, stopped, error }

class VoiceSessionController extends ChangeNotifier {
  final IGatewayClient gateway;
  final IAudioEngine audio;

  VoiceUiState uiState = VoiceUiState.ready;

  AdverseEventReport draft = AdverseEventReport.empty();
  String transcriptPartial = '';
  String transcriptFinal = '';
  String narrativePreview = '';
  String? emergencyBanner;
  String? lastError;

  int _lastSeqApplied = 0;
  StreamSubscription<GatewayEvent>? _sub;

  VoiceSessionController({
    required this.gateway,
    required this.audio,
  });

  Future<void> start({
    required Uri gatewayUrl,
    required String firebaseIdToken,
    required Map<String, dynamic> sessionConfig,
  }) async {
    try {
      _setState(VoiceUiState.connecting);

      // Prepare audio playback first
      try {
        await audio.playback.prepare();
      } catch (e) {
        lastError = 'Failed to prepare audio playback: $e';
        _setState(VoiceUiState.error);
        return;
      }

      // Connect to gateway
      try {
        await gateway.connect(
          url: gatewayUrl,
          firebaseIdToken: firebaseIdToken,
          sessionConfig: sessionConfig,
        );
      } catch (e) {
        lastError = 'Failed to connect to gateway: $e';
        _setState(VoiceUiState.error);
        // Cleanup audio on connection failure
        await audio.playback.dispose();
        return;
      }

      // Set up event listener
      _sub?.cancel();
      _sub = gateway.events.listen(_onGatewayEvent, onError: (e) {
        lastError = e.toString();
        _setState(VoiceUiState.error);
      });

      _setState(VoiceUiState.listening);

      // Start mic capture and forward to gateway
      try {
        await audio.capture.start(onPcm16k: (pcm16k) async {
          try {
            // base64 encode the bytes
            final b64 = base64Encode(pcm16k);
            await gateway.sendAudioChunkBase64(b64);
          } catch (e) {
            // Log but don't crash on audio send errors
            print('Warning: Failed to send audio chunk: $e');
          }
        });
      } catch (e) {
        lastError = 'Failed to start audio capture: $e';
        _setState(VoiceUiState.error);
        // Cleanup on capture failure
        await gateway.close();
        await audio.playback.dispose();
        return;
      }
    } catch (e) {
      // Catch-all for any unexpected errors
      lastError = 'Unexpected error during start: $e';
      _setState(VoiceUiState.error);
      // Ensure cleanup
      await stop();
    }
  }

  Future<void> stop() async {
    try {
      // Stop capture first
      try {
        await audio.capture.stop();
      } catch (e) {
        print('Warning: Error stopping audio capture: $e');
      }

      // Send stop to gateway
      try {
        await gateway.sendStop();
      } catch (e) {
        print('Warning: Error sending stop to gateway: $e');
      }

      // Close gateway connection
      try {
        await gateway.close();
      } catch (e) {
        print('Warning: Error closing gateway: $e');
      }

      // Stop and flush playback
      try {
        await audio.playback.stopNow();
      } catch (e) {
        print('Warning: Error stopping audio playback: $e');
      }

      _setState(VoiceUiState.stopped);
    } catch (e) {
      // Ensure state is updated even if cleanup fails
      _setState(VoiceUiState.stopped);
      lastError = 'Error during stop: $e';
      notifyListeners();
    }
  }

  void _onGatewayEvent(GatewayEvent ev) async {
    // Ordering guard: drop out-of-order events
    if (ev.seq != 0 && ev.seq <= _lastSeqApplied) return;
    _lastSeqApplied = ev.seq;

    switch (ev.type) {
      case GatewayEventType.sessionState: {
        final state = ev.payload['state'] as String? ?? '';
        if (state == 'listening') _setState(VoiceUiState.listening);
        if (state == 'speaking') _setState(VoiceUiState.speaking);
        if (state == 'processing') _setState(VoiceUiState.processing);
        if (state == 'stopped') _setState(VoiceUiState.stopped);
        break;
      }

      case GatewayEventType.transcriptPartial: {
        transcriptPartial = ev.payload['text'] as String? ?? '';
        notifyListeners();
        break;
      }

      case GatewayEventType.transcriptFinal: {
        final text = ev.payload['text'] as String? ?? '';
        if (text.isNotEmpty) {
          transcriptFinal = (transcriptFinal.isEmpty) ? text : '$transcriptFinal\n$text';
          transcriptPartial = '';
          notifyListeners();
        }
        break;
      }

      case GatewayEventType.narrativeUpdate: {
        // Accept either {"text": "..."} or {"patch": {"narrative": "..."}}
        if (ev.payload['text'] is String) {
          narrativePreview = ev.payload['text'] as String;
          draft = draft.applyJsonPatch({'narrative': narrativePreview});
        } else if (ev.payload['patch'] is Map) {
          final patch = (ev.payload['patch'] as Map).cast<String, dynamic>();
          draft = draft.applyJsonPatch(patch);
          narrativePreview = draft.narrative;
        }
        notifyListeners();
        break;
      }

      case GatewayEventType.aeDraftUpdate: {
        final patch = (ev.payload['patch'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
        draft = draft.applyJsonPatch(patch);
        notifyListeners();
        break;
      }

      case GatewayEventType.audioOut: {
        // Payload: {"data": "<base64 pcm24k>"}
        final data = ev.payload['data'] as String?;
        if (data != null && data.isNotEmpty) {
          final bytes = base64Decode(data);
          await audio.playback.feed(Uint8List.fromList(bytes));
        }
        break;
      }

      case GatewayEventType.audioStop: {
        // BARGE-IN: flush audio immediately.
        await audio.playback.stopNow();
        _setState(VoiceUiState.listening);
        break;
      }

      case GatewayEventType.emergency: {
        emergencyBanner = ev.payload['banner'] as String? ??
            'If you are experiencing severe symptoms, please seek urgent medical care.';
        _setState(VoiceUiState.emergency);
        break;
      }

      case GatewayEventType.error: {
        lastError = ev.payload['message'] as String? ?? 'Unknown gateway error';
        _setState(VoiceUiState.error);
        break;
      }
    }
  }

  void clearEmergency() {
    emergencyBanner = null;
    if (uiState == VoiceUiState.emergency) {
      _setState(VoiceUiState.listening);
    }
  }

  void _setState(VoiceUiState next) {
    if (uiState == next) return;
    uiState = next;
    notifyListeners();
  }

  @override
  Future<void> dispose() async {
    try {
      await _sub?.cancel();
      _sub = null;
    } catch (e) {
      print('Warning: Error canceling subscription: $e');
    }

    try {
      await audio.dispose();
    } catch (e) {
      print('Warning: Error disposing audio: $e');
    }

    try {
      await gateway.close();
    } catch (e) {
      print('Warning: Error closing gateway: $e');
    }

    super.dispose();
  }
}
