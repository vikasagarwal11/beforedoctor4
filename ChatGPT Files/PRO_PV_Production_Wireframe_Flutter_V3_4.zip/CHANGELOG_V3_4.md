# V3.4 – Voice-first “Gemini-like” home + simplified primary interaction

## Goal
Make the default user experience feel like a simple voice assistant screen:
- minimal controls
- live captions
- tone selector
- hands-free mode (wireframe)
All other features remain accessible, but not cluttering the main voice surface.

## Major changes
- App launches into the new **Voice** tab by default.
- New tab structure: **Timeline / Voice / Library / Insights / Profile**
- New VoiceHubScreen: minimal live caption + waveform stub + big mic button.
- “More” settings moved into a bottom sheet from the Voice tab (tone + hands-free).
- Timeline screen decluttered: removed floating mic/speed-dial overlays; quick log + search remain.

## Notes
- Still wireframe-only (no STT/LLM/TTS). Buttons simulate behavior.
